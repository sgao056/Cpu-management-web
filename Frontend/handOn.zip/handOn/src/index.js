import React from 'react';
import ReactDOM from 'react-dom';
import Router from './Router'


ReactDOM.render(
  <div>
    <Router/>
  </div>  
  ,
  document.getElementById('root')
);
